/*
 * DO NOT EDIT.  THIS FILE IS GENERATED FROM nsIMessengerFreeDesktopIntegration.idl
 */

#ifndef __gen_nsIMessengerFreeDesktopIntegration_h__
#define __gen_nsIMessengerFreeDesktopIntegration_h__


#ifndef __gen_nsISupports_h__
#include "nsISupports.h"
#endif

/* For IDL files that don't want to include root IDL files. */
#ifndef NS_NO_VTABLE
#define NS_NO_VTABLE
#endif

/* starting interface:    nsIMessengerFreeDesktopIntegration */
#define NS_IMESSENGERFREEDESKTOPINTEGRATION_IID_STR "0a07c43c-9253-11d9-b5b3-0020182e3f64"

#define NS_IMESSENGERFREEDESKTOPINTEGRATION_IID \
  {0x0a07c43c, 0x9253, 0x11d9, \
    { 0xb5, 0xb3, 0x00, 0x20, 0x18, 0x2e, 0x3f, 0x64 }}

class NS_NO_VTABLE nsIMessengerFreeDesktopIntegration : public nsISupports {
 public: 

  NS_DEFINE_STATIC_IID_ACCESSOR(NS_IMESSENGERFREEDESKTOPINTEGRATION_IID)

  enum { ASUS_LED_OK = 0U };

  enum { ASUS_LED_MISSING = 1U };

  enum { ASUS_LED_INACCESSIBLE = 2U };

  /* readonly attribute short asusLedStatus; */
  NS_IMETHOD GetAsusLedStatus(PRInt16 *aAsusLedStatus) = 0;

};

/* Use this macro when declaring classes that implement this interface. */
#define NS_DECL_NSIMESSENGERFREEDESKTOPINTEGRATION \
  NS_IMETHOD GetAsusLedStatus(PRInt16 *aAsusLedStatus); 

/* Use this macro to declare functions that forward the behavior of this interface to another object. */
#define NS_FORWARD_NSIMESSENGERFREEDESKTOPINTEGRATION(_to) \
  NS_IMETHOD GetAsusLedStatus(PRInt16 *aAsusLedStatus) { return _to GetAsusLedStatus(aAsusLedStatus); } 

/* Use this macro to declare functions that forward the behavior of this interface to another object in a safe way. */
#define NS_FORWARD_SAFE_NSIMESSENGERFREEDESKTOPINTEGRATION(_to) \
  NS_IMETHOD GetAsusLedStatus(PRInt16 *aAsusLedStatus) { return !_to ? NS_ERROR_NULL_POINTER : _to->GetAsusLedStatus(aAsusLedStatus); } 

#if 0
/* Use the code below as a template for the implementation class for this interface. */

/* Header file */
class nsMessengerFreeDesktopIntegration : public nsIMessengerFreeDesktopIntegration
{
public:
  NS_DECL_ISUPPORTS
  NS_DECL_NSIMESSENGERFREEDESKTOPINTEGRATION

  nsMessengerFreeDesktopIntegration();

private:
  ~nsMessengerFreeDesktopIntegration();

protected:
  /* additional members */
};

/* Implementation file */
NS_IMPL_ISUPPORTS1(nsMessengerFreeDesktopIntegration, nsIMessengerFreeDesktopIntegration)

nsMessengerFreeDesktopIntegration::nsMessengerFreeDesktopIntegration()
{
  /* member initializers and constructor code */
}

nsMessengerFreeDesktopIntegration::~nsMessengerFreeDesktopIntegration()
{
  /* destructor code */
}

/* readonly attribute short asusLedStatus; */
NS_IMETHODIMP nsMessengerFreeDesktopIntegration::GetAsusLedStatus(PRInt16 *aAsusLedStatus)
{
    return NS_ERROR_NOT_IMPLEMENTED;
}

/* End of implementation class template. */
#endif


#endif /* __gen_nsIMessengerFreeDesktopIntegration_h__ */
