// Determines whether to show system tray icon for biff.
pref("mail.biff.show_icon", true);
pref("mail.biff.show_asus_led", true);
