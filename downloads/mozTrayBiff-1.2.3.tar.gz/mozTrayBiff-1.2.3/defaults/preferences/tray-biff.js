// Determines whether to show system tray icon for biff.
pref("mail.biff.show_icon", true);
pref("mail.biff.use_hw_indicator", true);
pref("mail.biff.always_show_icon", false);
pref("mail.biff.hw_indicator_file", "");
pref("mail.biff.use_keyboard_led", 0);
